#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QIcon>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    drawingArea = new DrawingArea(this);
    drawingArea->setStyleSheet("border: 3px solid black;");
    ui->verticalLayout->addWidget(drawingArea);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_rectangle_clicked()
{
    drawingArea->setCurrentMode("Rectangle");
}

void MainWindow::on_ellipse_clicked()
{
    drawingArea->setCurrentMode("Ellipse");
}

void MainWindow::on_triangle_clicked()
{
    drawingArea->setCurrentMode("Triangle");
}

void MainWindow::on_connection_clicked()
{
    drawingArea->setCurrentMode("Connection");
}

void MainWindow::on_move_clicked()
{
    drawingArea->setCurrentMode("");
    drawingArea->setMoving(true);
}

void MainWindow::on_delete_2_clicked()
{
    drawingArea->setCurrentMode("");
    drawingArea->setDeleting(true);
}

void MainWindow::on_save_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save Drawing"), "", tr("Images (*.jpg *.png)"));
    if (!fileName.isEmpty()) {
        drawingArea->saveToFile(fileName);
    }
}
