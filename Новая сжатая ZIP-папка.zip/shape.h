#ifndef SHAPE_H
#define SHAPE_H

#include <QPainter>
#include <QPoint>

class MyShape {
public:
    virtual ~MyShape() {}
    virtual void draw (QPainter &painter) const = 0;
    virtual bool contains (const QPoint &point) const = 0;
    virtual void move (const QPoint &offset) = 0;
    virtual QRect &boundingRect () = 0;
};

class RectangleShape : public MyShape {
private:
    QRect rect;
public:
    RectangleShape(const QRect &otherrect) : rect(otherrect) {}
    void draw(QPainter &painter) const override {
        painter.drawRect(rect);
    }
    bool contains(const QPoint &point) const override {
        return rect.contains(point);
    }
    void move(const QPoint &offset) override {
        rect.translate(offset);
    }
    QRect &boundingRect() override {
        return rect;
    }
};

class EllipseShape : public MyShape {
private:
    QRect rect;
public:
    EllipseShape(const QRect &otherrect) : rect(otherrect) {}
    void draw(QPainter &painter) const override {
        painter.drawEllipse(rect);
    }
    bool contains(const QPoint &point) const override {
        return rect.contains(point);
    }
    void move(const QPoint &offset) override {
        rect.translate(offset);
    }
    QRect &boundingRect() override {
        return rect;
    }
};

class TriangleShape : public MyShape {
private:
    QRect rect;
public:
    TriangleShape(const QRect &otherrect) : rect(otherrect) {}
    void draw(QPainter &painter) const override {
        QPolygon triangle;
        triangle << QPoint(rect.left() + rect.width() / 2, rect.top())
                 << QPoint(rect.bottomLeft())
                 << QPoint(rect.bottomRight());
        painter.drawPolygon(triangle);
    }
    bool contains(const QPoint &point) const override {
        return rect.contains(point);
    }
    void move(const QPoint &offset) override {
        rect.translate(offset);
    }
    QRect &boundingRect() override {
        return rect;
    }
};

#endif // SHAPE_H
